#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import re
import trimesh

def  merge_axial_elements_main():

    input_mesh_files = ['head ExpHull.obj','neck ExpHull.obj','trunk ExpHull.obj','tail ExpHull.obj']
    output_union_file = 'axial_skeleton ExpHull.obj'
    merge_axial_elements(input_mesh_files, output_union_file)
    
    input_mesh_files = ['head hull.obj','neck hull.obj','trunk hull.obj','tail hull.obj']
    output_union_file = 'axial_skeleton hull.obj'
    merge_axial_elements(input_mesh_files, output_union_file)
    
    

def merge_axial_elements(input_mesh_files, output_union_file):
    for file in input_mesh_files:
        preflight_read_file(file, True)
    
    meshlist = []
    for file in input_mesh_files:
       meshlist.append(trimesh.load(file, process=True))
       
    for mesh in meshlist:
        if mesh.is_watertight: print('Mesh is watertight')
        else: print('Mesh is not watertight')
        if mesh.is_winding_consistent: print('Mesh has consistent winding')
        else: print('Mesh has inconsistent winding')
    
    # union_mesh = trimesh.boolean.union(meshlist, engine='scad') # the blender version seems to work better
    # union_mesh = trimesh.boolean.union(meshlist, engine='blender')
    union_mesh = trimesh.boolean.union(meshlist, engine=None)
    if union_mesh.is_watertight: print('Union mesh is watertight')
    else:
        print('Union mesh is not watertight')
        trimesh.repair.fill_holes(union_mesh)
        if union_mesh.is_watertight: print('Union mesh is repaired')
        else: print('Union mesh is not repaired')
    if union_mesh.is_winding_consistent: print('Union mesh has consistent winding')
    else: print('Union mesh has inconsistent winding')
    
    preflight_write_file(file, True, True)
    union_mesh.export(output_union_file)

def preflight_read_file(filename, verbose):
    if verbose: print('preflight_read_file: "%s"' % (filename))
    if not os.path.exists(filename):
        print("Error: \"%s\" not found" % (filename))
        sys.exit(1)
    if not os.path.isfile(filename):
        print("Error: \"%s\" not a file" % (filename))
        sys.exit(1)

def preflight_write_file(filename, force, verbose):
    if verbose: print('preflight_write_file: "%s"' % (filename))
    if os.path.exists(filename) and not os.path.isfile(filename):
        print("Error: \"%s\" exists and is not a file" % (filename))
        sys.exit(1)
    if os.path.exists(filename) and not force:
        print("Error: \"%s\" exists. Use --force to overwrite" % (filename))
        sys.exit(1)

def preflight_read_folder(folder, verbose):
    if verbose: print('preflight_read_folder: "%s"' % (folder))
    if not os.path.exists(folder):
        print("Error: \"%s\" not found" % (folder))
        sys.exit(1)
    if not os.path.isdir(folder):
        print("Error: \"%s\" not a folder" % (folder))
        sys.exit(1)

def preflight_write_folder(folder, verbose):
    if verbose: print('preflight_write_folder: "%s"' % (folder))
    if os.path.exists(folder):
        if not os.path.isdir(folder):
            print("Error: \"%s\" exists and is not a folder" % (folder))
            sys.exit(1)
    else:
        try:
            os.makedirs(folder, exist_ok = True)
        except OSError as error:
            print(error)
            print('Directory "%s" can not be created' % folder)
            sys.exit(1)

def is_a_number(string):
    """checks to see whether a string is a valid number"""
    if re.match(r'^([+-]?)(?=\d|\.\d)\d*(\.\d*)?([Ee]([+-]?\d+))?$', string.strip()) == None:
        return False
    return True

def pretty_print_sys_argv(sys_argv):
    quoted_sys_argv = quoted_if_necessary(sys_argv)
    print((" ".join(quoted_sys_argv)))

def pretty_print_argparse_args(argparse_args):
    for arg in vars(argparse_args):
        print(("%s: %s" % (arg, getattr(argparse_args, arg))))

def quoted_if_necessary(input_list):
    output_list = []
    for item in input_list:
        if re.search(r"[^a-zA-Z0-9_.-]", item): # note inside [] backslash quoting does not work so a minus sign to match must occur last
            item = "\"" + item + "\""
        output_list.append(item)
    return output_list

# program starts here

if __name__ == '__main__':
    merge_axial_elements_main()
    

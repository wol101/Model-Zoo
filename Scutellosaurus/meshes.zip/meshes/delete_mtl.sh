#!/bin/bash

for f in *.obj
do
    # this line deletes in place all lines containing mtl
    # e.g. mtllib usemtl
    sed -i '/mtl/d' "${f}"
done
